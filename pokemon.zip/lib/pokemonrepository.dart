import 'dart:convert';

import 'package:pokemon/pokemonpage.dart';
import 'package:http/http.dart' as http;

class PokemonRepository {
  final baseUrl = 'pokeapi.co';
  final Client = http.Client();

  Future<PokemonPage> getPokemonPage(int pageIndex) async {
    //pokemon?limit=200&offset=400

    final queryParameters = {
      'limit': '200',
      'offset': (pageIndex * 200).toString()
    };

    final uri = Uri.https(baseUrl, 'api/v2/pokemon', queryParameters);

    final response = await client.get(uri);
    final json = jsonDecode(response.body);

    return PokemonPage.fromJson(json);
  }
}
